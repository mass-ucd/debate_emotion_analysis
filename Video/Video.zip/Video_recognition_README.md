
# POL42560 Final Project: Emotional Expression in the 2024 Trump vs. Harris Presidential Debate

This project analyzes the **emotional and linguistic expression** in the full-length **2024 U.S. Presidential Debate between Donald Trump and Kamala Harris**. 
A Python-based framework for analyzing facial expressions and emotions in political debate videos using computer vision and machine learning.

## Overview

This repository contains code for extracting, processing, and analyzing facial expressions from debate videos. The system detects faces, facial landmarks, action units (AUs), and emotions throughout the debate timeline, producing both quantitative data and visualizations for further analysis.

## Key Features

- **Frame Extraction**: Systematic extraction of video frames at configurable frame rates
- **Facial Analysis**: Detection of faces, landmarks, action units, and emotions
- **Candidate Identification**: Automatic clustering to distinguish between debate participants
- **Temporal Analysis**: Time-series emotion tracking throughout the debate
- **Comprehensive Visualizations**: Static and interactive visualizations of emotional patterns
- **Apple Silicon Optimization**: Enhanced performance on M1/M2 Macs

## Technical Implementation

### Dependencies

The project relies on the following key libraries:
- `py-feat`: Core facial expression analysis toolkit
- `OpenCV` (cv2): Video processing and frame extraction
- `NumPy` & `Pandas`: Data manipulation and analysis
- `scikit-learn`: Clustering for candidate identification
- `Matplotlib`, `Seaborn`, & `Plotly`: Data visualization
- `tqdm`: Progress tracking
- `PIL`: Image processing

### Pipeline Architecture

#### 1. Frame Extraction
The system extracts frames at a specified rate (default: 1 fps) using OpenCV's `VideoCapture`. Each frame is saved with timestamp metadata for temporal alignment. The extraction process includes:
- Video metadata retrieval (fps, duration, frame count)
- Calculation of extraction interval based on desired frame rate
- Systematic extraction and saving of frames with progress tracking

#### 2. Facial Analysis
Using the `py-feat` library, the pipeline employs multiple specialized models:
- **Face Detection**: RetinaFace model for robust face detection
- **Facial Landmarks**: MobileFaceNet for 68-point landmark detection
- **Action Units**: XGBoost classifier for FACS Action Unit recognition
- **Emotion Classification**: ResMaskNet for 7-emotion classification (anger, disgust, fear, happiness, sadness, surprise, neutral)
- **Face Pose Estimation**: img2pose for head orientation analysis

Frames are processed in configurable batches to optimize memory usage. Each detection includes:
- Face bounding box coordinates
- Confidence scores
- 68 facial landmarks
- 20 Action Unit intensities
- 7 emotion probabilities
- Head pose information

#### 3. Candidate Identification
The system uses unsupervised learning to distinguish between debate participants:
- **Face Position Clustering**: K-means clustering on facial positions across frames
- **Cluster Mapping**: Assignment of candidate labels based on cluster frequencies
- **Detection Confidence Filtering**: Thresholding to include only high-confidence detections
- **Alternative Positioning**: Fallback to facial landmark averaging when bounding boxes are unreliable

#### 4. Temporal Analysis
The raw detection data is organized into temporal bins for trend analysis:
- **Minute Binning**: Aggregation of data into one-minute intervals
- **Time-Series Construction**: Tracking of emotions and AUs across debate timeline
- **Statistical Aggregation**: Mean emotion/AU values calculated for each temporal bin

#### 5. Visualization Generation
Multiple visualization types are automatically generated:
- **Emotion Timelines**: Line plots showing emotion intensity fluctuations
- **AU Heatmaps**: Intensity visualization of Action Units over time
- **Dominant Emotion Charts**: Pie charts showing proportion of dominant emotions
- **AU Comparison Plots**: Bar charts comparing AU usage between candidates
- **Interactive Plots**: HTML-based Plotly visualizations for detailed exploration

### Memory & Performance Optimization

The code implements several optimizations:
- **Batch Processing**: Frames are processed in configurable batches (default: 10)
- **Intermediate Saving**: Results are periodically saved to prevent data loss
- **Hardware Detection**: Automatic detection of Apple Silicon for optimization
- **Error Handling**: Robust exception handling throughout the pipeline

## Usage

### Basic Usage

```python
from debate_analysis import analyze_debate

# Run analysis on a debate video
results, visualizations = analyze_debate(
    video_path="debate_video.mp4",
    candidate_names=["Trump", "Harris"],
    frame_rate=1,
    batch_size=10
)
```

### Advanced Configuration

```python
# With custom candidate reference images
results, visualizations = analyze_debate(
    video_path="debate_video.mp4",
    candidate_images={
        "Trump": "reference_trump.jpg",
        "Harris": "reference_harris.jpg"
    },
    candidate_names=["Trump", "Harris"],
    frame_rate=1,  # Extract 1 frame per second
    max_frames=None,  # Process all frames (set a number to limit)
    batch_size=10,  # Process 10 frames at a time
    output_dir="custom_output",
    save_intermediate=True  # Save interim results
)
```

## Output Structure

The analysis produces:
- **Extracted Frames**: Saved in `output/frames/`
- **CSV Results**: Complete analysis data in `output/results/`
- **Visualizations**: Generated plots in `output/visualizations/`

## Implementation Details

### Key Functions

- `extract_frames()`: Extracts and saves frames from video
- `process_frames_in_batches()`: Processes frames with facial analysis
- `identify_candidates()`: Clusters and labels detected faces
- `calculate_minute_bins()`: Groups data into temporal intervals
- `analyze_debate()`: Main pipeline wrapper function
- `create_debate_visualizations()`: Generates analysis visualizations

### Error Handling

The system includes robust error handling to manage:
- Missing face detections
- Invalid or corrupted frames
- Memory constraints in batch processing
- API compatibility issues between py-feat versions

### Extension Points

The codebase can be extended through:
- Adding new visualization types
- Implementing additional emotion models
- Extending to multi-person detection
- Adding textual transcript alignment

## Requirements

- Python 3.8+
- py-feat (latest version)
- OpenCV
- NumPy
- Pandas
- scikit-learn
- Matplotlib
- Seaborn
- Plotly
- tqdm
- PIL

## Citation

If you use this code in your research, please cite:

```
@software{debate_facial_analysis,
  author = {Moisés A. Silva},
  title = {Political Debate Facial Expression Analysis},
  year = {2025},
  url = {https://github.com/username/debate-facial-analysis}
}
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.