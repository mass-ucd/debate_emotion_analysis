Ai prompt usage:


Prompt: "I want to analyze an hour and a half long debate using pyfeat functionalities to identify facial activation units and the emotion associated witht the combination of them. To help the models with identification I have two jpg images of both trump and Harris if needed. 
Goal: Create an exhaustive step by step code intensive guide to create a notebook that fulfil this goal for an apple silicon setup, draw inspiration from this sources:
Expressions from video: https://py-feat.org/basic_tutorials/02_detector_vids.html
Full analysis: https://py-feat.org/basic_tutorials/04_fex_analysis.html

I want to plot the facial activation units per candidate, and the evolution of emotions over the debate (lineplot with emotion and minutes), feel free to add appropriate additional visualizations 
Create a conda virtual environment for this to avoid dependencies issues and implement measures for optimization, I want the process to be as fast as possible for a whole 1.5 hour debate"

Model: Claude 3.7 Sonnet with default settings

Sharable link: https://claude.ai/public/artifacts/2207f940-9d41-4533-a538-df7655553362

Response: 

# PyFEAT Video Emotion Analysis Guide for Political Debates

I'll create a comprehensive guide to analyze facial expressions and emotions in a debate video using py-feat, optimized for Apple Silicon.

Let me build a notebook that will:
1. Set up a proper conda environment
2. Process a 1.5-hour debate video
3. Extract facial action units and emotions for each candidate
4. Visualize the results with appropriate plots

I've created a comprehensive notebook for analyzing facial expressions and emotions in a political debate video using py-feat. This solution is specifically optimized for Apple Silicon devices and includes:

## Key Features

1. **Optimized Environment Setup**
   - Creates a dedicated conda environment with all necessary dependencies
   - Configures TensorFlow Metal for Apple Silicon GPU acceleration

2. **Efficient Video Processing**
   - Uses multiprocessing to parallelize analysis across CPU cores
   - Processes video at customizable intervals (default: 1 frame per second)

3. **Candidate Identification**
   - Uses facial embeddings to match detected faces with reference images
   - Provides similarity scores for reliable candidate tracking

4. **Comprehensive Visualizations**
   - Action Unit intensity comparison between candidates
   - Emotion evolution over time (line plots for each emotion)
   - Emotion distribution violin plots
   - Time-based emotion heatmaps
   - Emotional peak detection and visualization

5. **Performance Optimizations**
   - Uses Metal Performance Shaders (MPS) backend when available
   - Batched processing to manage memory usage
   - Frame extraction at optimal intervals to balance accuracy and speed

## How to Use the Notebook

1. **Set Up Environment**
   - Follow the conda setup instructions at the beginning of the notebook
   - Install all required dependencies

2. **Prepare Your Data**
   - Place your debate video at the specified path (`debate_video.mp4`)
   - Add reference images of the candidates (`trump.jpg` and `harris.jpg`)

3. **Configure Analysis**
   - Adjust processing parameters if needed (frame interval, batch size, etc.)
   - Set output directory for results

4. **Run the Analysis**
   - Execute the `main()` function to run the entire pipeline
   - The analysis will process the video, extract facial features, and generate visualizations

5. **Review Results**
   - Check the output directory for CSV data and visualization images
   - Examine emotional peaks and patterns throughout the debate

Would you like me to explain any particular section of the code in more detail, or would you like guidance on how to adapt this for your specific needs?


Code: 

#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Political Debate Facial Emotion Analysis with Py-FEAT
=====================================================

This notebook provides a comprehensive pipeline for analyzing facial expressions and emotions
in political debate videos using the py-feat library, optimized for Apple Silicon.

"""

# %% [markdown]
# # Setting Up the Environment
# 
# First, we'll create a conda environment with all the necessary dependencies.
# 
# ```bash
# # Create a new conda environment
# conda create -n pyfeat python=3.9 -y
# conda activate pyfeat
# 
# # Install py-feat and other dependencies
# pip install py-feat
# pip install matplotlib pandas seaborn jupyter opencv-python tqdm ipywidgets
# 
# # For Apple Silicon optimization
# conda install -c conda-forge tensorflow-macos -y
# conda install -c apple tensorflow-metal -y  # GPU acceleration for M1/M2/M3
# 
# # Install ffmpeg for video processing
# conda install -c conda-forge ffmpeg -y
# ```

# %% [markdown]
# # Import Libraries

# %%
import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import cv2
from tqdm.notebook import tqdm
from PIL import Image
import multiprocessing as mp
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Import py-feat
from feat import Detector
from feat.utils import read_pictures, read_videos
from feat.plotting import plot_face, plot_aus, plot_emotions

# Set plotting style
sns.set(style="whitegrid")
plt.rcParams['figure.figsize'] = (14, 8)
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['axes.labelsize'] = 14

# %% [markdown]
# # Configuration

# %%
# Paths and configuration
VIDEO_PATH = "debate_video.mp4"  # Path to your 1.5 hour debate video
CANDIDATES = {
    "trump": {"img_path": "trump.jpg", "color": "red"},
    "harris": {"img_path": "harris.jpg", "color": "blue"}
}

# Processing configuration
FACE_DETECTION_BATCH_SIZE = 32  # Adjust based on your memory
PROCESSING_INTERVAL = 1  # Process 1 frame per second (adjust for precision vs speed)
NUM_PROCESSES = mp.cpu_count() - 1  # Use all but one CPU core
FACE_DETECTION_THRESHOLD = 0.8  # Minimum confidence for face detection
OUTPUT_DIR = "debate_analysis_results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# %% [markdown]
# # Initialize the Face Detector
# 
# We'll use py-feat's Detector to process the video and extract facial expressions.

# %%
def initialize_detector():
    """Initialize the py-feat detector with optimized settings for Apple Silicon."""
    detector = Detector(
        face_model="retinaface", 
        landmark_model="mobilefacenet",
        au_model="xgb", 
        emotion_model="resmasknet",
        facepose_model="img2pose",
        device="mps" if hasattr(torch, 'mps') and torch.backends.mps.is_available() else "cpu"
    )
    return detector

# Import torch after defining the function for clarity
import torch
detector = initialize_detector()

# %% [markdown]
# # Load Reference Images
# 
# Let's load the reference images of the candidates to help with identification.

# %%
def load_reference_faces():
    """Load and detect faces in reference candidate images."""
    reference_faces = {}
    
    for candidate, info in CANDIDATES.items():
        try:
            # Load and process reference image
            img_path = info["img_path"]
            img = Image.open(img_path)
            
            # Get face embeddings from reference image
            reference_detection = detector.detect_faces(img)
            reference_landmarks = detector.detect_landmarks(img, reference_detection)
            reference_embedding = detector.get_embedding(img, reference_detection, reference_landmarks)
            
            reference_faces[candidate] = reference_embedding
            print(f"✓ Loaded reference face for {candidate.capitalize()}")
        except Exception as e:
            print(f"✗ Failed to load reference for {candidate}: {str(e)}")
    
    return reference_faces

reference_faces = load_reference_faces()

# %% [markdown]
# # Video Processing Functions

# %%
def get_video_info(video_path):
    """Get video information (duration, fps, total frames)."""
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        raise ValueError(f"Could not open video file: {video_path}")
    
    # Get video properties
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    duration_seconds = total_frames / fps
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    cap.release()
    
    return {
        "total_frames": total_frames,
        "fps": fps,
        "duration_seconds": duration_seconds,
        "duration_formatted": f"{int(duration_seconds//3600):02d}:{int((duration_seconds%3600)//60):02d}:{int(duration_seconds%60):02d}",
        "width": width,
        "height": height
    }

# %%
def extract_frames(video_path, interval=1):
    """
    Extract frames from video at specified intervals.
    
    Args:
        video_path: Path to video file
        interval: Extract 1 frame every `interval` seconds
        
    Returns:
        List of (timestamp, frame) tuples
    """
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        raise ValueError(f"Could not open video file: {video_path}")
    
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_interval = int(fps * interval)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    frames = []
    frame_indices = range(0, total_frames, frame_interval)
    
    for frame_idx in tqdm(frame_indices, desc="Extracting frames"):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ret, frame = cap.read()
        
        if ret:
            timestamp = frame_idx / fps  # timestamp in seconds
            # Convert from BGR to RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frames.append((timestamp, frame_rgb))
        else:
            break
    
    cap.release()
    return frames

# %% [markdown]
# # Face Detection and Matching Functions

# %%
def calculate_embedding_similarity(embedding1, embedding2):
    """Calculate cosine similarity between two face embeddings."""
    return np.dot(embedding1, embedding2) / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))

# %%
def identify_candidate(face_embedding, reference_faces, threshold=0.6):
    """Identify which candidate a detected face belongs to based on reference embeddings."""
    max_similarity = -1
    identified_candidate = None
    
    for candidate, ref_embedding in reference_faces.items():
        similarity = calculate_embedding_similarity(face_embedding, ref_embedding)
        if similarity > max_similarity and similarity > threshold:
            max_similarity = similarity
            identified_candidate = candidate
    
    return identified_candidate, max_similarity

# %%
def process_batch(frames_batch, detector, reference_faces):
    """
    Process a batch of frames to detect faces and extract facial features.
    
    Args:
        frames_batch: List of (timestamp, frame) tuples
        detector: Initialized py-feat detector
        reference_faces: Dictionary of reference face embeddings
        
    Returns:
        List of processed results (timestamp, candidate, facial analysis)
    """
    results = []
    
    for timestamp, frame in frames_batch:
        try:
            # Detect faces in the frame
            faces = detector.detect_faces(frame)
            
            if faces is None or len(faces) == 0:
                continue
            
            # For each detected face
            for i, face_bbox in enumerate(faces):
                # Extract landmarks and embeddings
                landmarks = detector.detect_landmarks(frame, faces[i:i+1])
                embedding = detector.get_embedding(frame, faces[i:i+1], landmarks)
                
                # Identify the candidate
                candidate_id, similarity = identify_candidate(embedding, reference_faces)
                
                if candidate_id:
                    # Extract facial action units and emotions
                    aus = detector.detect_aus(frame, faces[i:i+1], landmarks)
                    emotions = detector.detect_emotions(frame, faces[i:i+1], landmarks)
                    
                    # Compile results
                    facial_analysis = {
                        'face_bbox': face_bbox,
                        'landmarks': landmarks,
                        'aus': aus,
                        'emotions': emotions,
                        'similarity': similarity
                    }
                    
                    results.append((timestamp, candidate_id, facial_analysis))
            
        except Exception as e:
            print(f"Error processing frame at {timestamp:.2f}s: {str(e)}")
    
    return results

# %%
def parallel_process_video(frames, detector, reference_faces, num_processes=NUM_PROCESSES):
    """
    Process video frames in parallel using multiple processes.
    
    Args:
        frames: List of (timestamp, frame) tuples
        detector: Initialized py-feat detector
        reference_faces: Dictionary of reference face embeddings
        num_processes: Number of parallel processes to use
        
    Returns:
        Combined results from all processes
    """
    # Split frames into batches for each process
    batch_size = len(frames) // num_processes
    if batch_size == 0:
        batch_size = 1
    
    batches = [frames[i:i+batch_size] for i in range(0, len(frames), batch_size)]
    
    # Create a pool of processes
    with mp.Pool(processes=num_processes) as pool:
        # Process each batch in parallel
        results = pool.starmap(
            process_batch, 
            [(batch, detector, reference_faces) for batch in batches]
        )
    
    # Combine results from all processes
    combined_results = []
    for batch_results in results:
        combined_results.extend(batch_results)
    
    return combined_results

# %% [markdown]
# # Main Processing Pipeline

# %%
def process_debate_video(video_path, detector, reference_faces, interval=PROCESSING_INTERVAL):
    """
    Main function to process the debate video.
    
    Args:
        video_path: Path to the debate video
        detector: Initialized py-feat detector
        reference_faces: Dictionary of reference face embeddings
        interval: Process 1 frame every `interval` seconds
        
    Returns:
        DataFrame with processed results
    """
    # Get video info
    video_info = get_video_info(video_path)
    print(f"Video Duration: {video_info['duration_formatted']}")
    print(f"Processing 1 frame every {interval} second(s)")
    
    # Extract frames at specified interval
    print("Extracting frames from video...")
    frames = extract_frames(video_path, interval=interval)
    print(f"Extracted {len(frames)} frames")
    
    # Process frames
    print(f"Processing frames using {NUM_PROCESSES} parallel processes...")
    start_time = time.time()
    results = parallel_process_video(frames, detector, reference_faces)
    processing_time = time.time() - start_time
    print(f"Processing completed in {processing_time:.2f} seconds")
    
    # Convert results to DataFrame
    print("Converting results to DataFrame...")
    data = []
    
    for timestamp, candidate, facial_analysis in results:
        # Extract action units (AUs)
        aus_data = {f"AU{i+1}": value for i, value in enumerate(facial_analysis['aus'][0])}
        
        # Extract emotions
        emotions_data = {emotion: value for emotion, value in 
                        zip(['anger', 'disgust', 'fear', 'happiness', 'sadness', 'surprise', 'neutral'],
                            facial_analysis['emotions'][0])}
        
        # Create a record
        record = {
            'timestamp': timestamp,
            'minutes': timestamp / 60,
            'candidate': candidate,
            'similarity': facial_analysis['similarity'],
            **aus_data,
            **emotions_data
        }
        
        data.append(record)
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Save results
    df.to_csv(f"{OUTPUT_DIR}/debate_analysis_results.csv", index=False)
    print(f"Results saved to {OUTPUT_DIR}/debate_analysis_results.csv")
    
    return df

# %% [markdown]
# # Data Analysis and Visualization

# %%
def analyze_and_visualize(df):
    """
    Analyze and visualize the extracted facial expression data.
    
    Args:
        df: DataFrame with processed results
    """
    if len(df) == 0:
        print("No data to analyze!")
        return
    
    print(f"Analyzing data for {df['candidate'].nunique()} candidates")
    print(f"Total data points: {len(df)}")
    
    # 1. Create time bins (5-minute intervals)
    df['time_bin'] = (df['minutes'] // 5) * 5
    
    # 2. Plot facial action units per candidate
    plot_facial_action_units(df)
    
    # 3. Plot emotion evolution over time
    plot_emotion_evolution(df)
    
    # 4. Plot emotion distributions per candidate
    plot_emotion_distributions(df)
    
    # 5. Plot emotion heatmap over time
    plot_emotion_heatmap(df)
    
    # 6. Plot key facial expressions during emotional peaks
    plot_emotional_peaks(df)

# %%
def plot_facial_action_units(df):
    """Plot average facial action units for each candidate."""
    # Get AU columns
    au_cols = [col for col in df.columns if col.startswith('AU')]
    
    # Calculate average AUs per candidate
    au_avg = df.groupby('candidate')[au_cols].mean().reset_index()
    
    # Reshape data for plotting
    au_melted = pd.melt(au_avg, id_vars=['candidate'], 
                        value_vars=au_cols, 
                        var_name='Action Unit', 
                        value_name='Intensity')
    
    # Create plot
    plt.figure(figsize=(16, 10))
    
    # Plot bars for each candidate
    sns.barplot(
        data=au_melted, 
        x='Action Unit', 
        y='Intensity', 
        hue='candidate',
        palette={cand: info['color'] for cand, info in CANDIDATES.items()}
    )
    
    plt.title('Average Facial Action Unit Intensity by Candidate', fontsize=18)
    plt.xlabel('Action Unit', fontsize=14)
    plt.ylabel('Intensity', fontsize=14)
    plt.xticks(rotation=45)
    plt.legend(title='Candidate')
    plt.tight_layout()
    
    # Save figure
    plt.savefig(f"{OUTPUT_DIR}/facial_action_units.png", dpi=300)
    plt.close()

# %%
def plot_emotion_evolution(df):
    """Plot the evolution of emotions over debate time."""
    # List of emotions
    emotions = ['anger', 'disgust', 'fear', 'happiness', 'sadness', 'surprise', 'neutral']
    
    # Create time bins for smoother visualization (1-minute bins)
    df['minute_bin'] = df['minutes'].astype(int)
    
    # Calculate average emotions per candidate and time bin
    emotion_over_time = df.groupby(['candidate', 'minute_bin'])[emotions].mean().reset_index()
    
    # Create one plot per emotion
    for emotion in emotions:
        plt.figure(figsize=(16, 6))
        
        for candidate in df['candidate'].unique():
            candidate_data = emotion_over_time[emotion_over_time['candidate'] == candidate]
            plt.plot(
                candidate_data['minute_bin'], 
                candidate_data[emotion],
                label=candidate.capitalize(),
                color=CANDIDATES[candidate]['color'],
                linewidth=2
            )
        
        # Add debate markers
        plt.axvspan(0, 5, alpha=0.1, color='gray', label='Introduction')
        # Add more debate segments as needed
        
        plt.title(f'Evolution of {emotion.capitalize()} During Debate', fontsize=18)
        plt.xlabel('Minutes into Debate', fontsize=14)
        plt.ylabel('Emotion Intensity', fontsize=14)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Save figure
        plt.savefig(f"{OUTPUT_DIR}/emotion_evolution_{emotion}.png", dpi=300)
        plt.close()
    
    # Create a combined plot with all emotions for each candidate
    for candidate in df['candidate'].unique():
        plt.figure(figsize=(16, 8))
        
        candidate_data = emotion_over_time[emotion_over_time['candidate'] == candidate]
        
        for emotion in emotions:
            plt.plot(
                candidate_data['minute_bin'],
                candidate_data[emotion],
                label=emotion.capitalize(),
                linewidth=2
            )
        
        plt.title(f'Emotion Evolution for {candidate.capitalize()} During Debate', fontsize=18)
        plt.xlabel('Minutes into Debate', fontsize=14)
        plt.ylabel('Emotion Intensity', fontsize=14)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Save figure
        plt.savefig(f"{OUTPUT_DIR}/emotion_evolution_{candidate}_all.png", dpi=300)
        plt.close()

# %%
def plot_emotion_distributions(df):
    """Plot distribution of emotions for each candidate."""
    # List of emotions
    emotions = ['anger', 'disgust', 'fear', 'happiness', 'sadness', 'surprise', 'neutral']
    
    # Reshape data for plotting
    emotion_melted = pd.melt(
        df, 
        id_vars=['candidate'], 
        value_vars=emotions,
        var_name='Emotion',
        value_name='Intensity'
    )
    
    # Create plot
    plt.figure(figsize=(14, 8))
    
    # Create violin plot
    sns.violinplot(
        data=emotion_melted,
        x='Emotion',
        y='Intensity',
        hue='candidate',
        palette={cand: info['color'] for cand, info in CANDIDATES.items()},
        split=True
    )
    
    plt.title('Distribution of Emotions by Candidate', fontsize=18)
    plt.xlabel('Emotion', fontsize=14)
    plt.ylabel('Intensity', fontsize=14)
    plt.legend(title='Candidate')
    plt.tight_layout()
    
    # Save figure
    plt.savefig(f"{OUTPUT_DIR}/emotion_distributions.png", dpi=300)
    plt.close()

# %%
def plot_emotion_heatmap(df):
    """Create a heatmap of emotions over time."""
    # List of emotions
    emotions = ['anger', 'disgust', 'fear', 'happiness', 'sadness', 'surprise', 'neutral']
    
    # Create time bins (5-minute intervals)
    df['time_bin'] = (df['minutes'] // 5) * 5
    
    # For each candidate
    for candidate in df['candidate'].unique():
        candidate_data = df[df['candidate'] == candidate]
        
        # Calculate average emotions per time bin
        emotion_matrix = candidate_data.groupby('time_bin')[emotions].mean()
        
        # Create heatmap
        plt.figure(figsize=(15, 8))
        sns.heatmap(
            emotion_matrix.T,
            cmap='RdBu_r',
            center=0.5,
            vmin=0,
            vmax=1,
            linewidths=0.5,
            annot=True,
            fmt='.2f',
            cbar_kws={'label': 'Emotion Intensity'}
        )
        
        plt.title(f'Emotion Heatmap for {candidate.capitalize()} Over Time', fontsize=18)
        plt.xlabel('Time (5-minute bins)', fontsize=14)
        plt.ylabel('Emotion', fontsize=14)
        plt.tight_layout()
        
        # Save figure
        plt.savefig(f"{OUTPUT_DIR}/emotion_heatmap_{candidate}.png", dpi=300)
        plt.close()

# %%
def plot_emotional_peaks(df):
    """Identify and plot key moments of emotional peaks."""
    # List of emotions
    emotions = ['anger', 'disgust', 'fear', 'happiness', 'sadness', 'surprise']
    
    # Find emotional peaks for each candidate and emotion
    peaks = []
    
    for candidate in df['candidate'].unique():
        candidate_data = df[df['candidate'] == candidate]
        
        for emotion in emotions:
            # Get top 3 moments for this emotion
            top_moments = candidate_data.nlargest(3, emotion)
            
            for _, moment in top_moments.iterrows():
                peaks.append({
                    'candidate': candidate,
                    'emotion': emotion,
                    'intensity': moment[emotion],
                    'timestamp': moment['timestamp'],
                    'minutes': moment['minutes']
                })
    
    # Convert to DataFrame
    peaks_df = pd.DataFrame(peaks)
    
    # Create plot
    plt.figure(figsize=(14, 10))
    
    for candidate in df['candidate'].unique():
        candidate_peaks = peaks_df[peaks_df['candidate'] == candidate]
        
        # Plot peaks
        sns.scatterplot(
            data=candidate_peaks,
            x='minutes',
            y='intensity',
            hue='emotion',
            style='emotion',
            s=150,
            alpha=0.7,
            label=candidate.capitalize(),
            edgecolor='black'
        )
    
    plt.title('Emotional Peaks During Debate', fontsize=18)
    plt.xlabel('Minutes into Debate', fontsize=14)
    plt.ylabel('Emotion Intensity', fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.legend(title='Emotion')
    
    # Save figure
    plt.savefig(f"{OUTPUT_DIR}/emotional_peaks.png", dpi=300)
    plt.close()
    
    # Create summary table of peaks
    summary = peaks_df.sort_values(['candidate', 'minutes'])
    summary.to_csv(f"{OUTPUT_DIR}/emotional_peaks_summary.csv", index=False)
    
    print(f"Top emotional moments saved to {OUTPUT_DIR}/emotional_peaks_summary.csv")

# %% [markdown]
# # Run the Complete Analysis

# %%
def main():
    """Run the complete analysis pipeline."""
    print("Starting debate video analysis...")
    
    # Initialize detector
    detector = initialize_detector()
    
    # Load reference faces
    reference_faces = load_reference_faces()
    
    # Process the debate video
    results_df = process_debate_video(VIDEO_PATH, detector, reference_faces)
    
    # Analyze and visualize results
    analyze_and_visualize(results_df)
    
    print(f"Analysis complete! Results saved to {OUTPUT_DIR}/")

# %%
if __name__ == "__main__":
    main()

# %% [markdown]
# # Additional Utilities

# %%
def display_sample_frames(video_path, interval=30, num_samples=10):
    """Display sample frames from the video for visual inspection."""
    frames = extract_frames(video_path, interval=interval)
    
    # Take a subset of frames
    sample_frames = frames[:min(num_samples, len(frames))]
    
    # Display frames
    fig, axes = plt.subplots(2, 5, figsize=(20, 8))
    axes = axes.flatten()
    
    for i, (timestamp, frame) in enumerate(sample_frames):
        if i >= len(axes):
            break
            
        axes[i].imshow(frame)
        axes[i].set_title(f"Time: {int(timestamp//60):02d}:{int(timestamp%60):02d}")
        axes[i].axis('off')
    
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/sample_frames.png", dpi=300)
    plt.close()

# %%
def optimize_for_apple_silicon():
    """Configure system for optimal performance on Apple Silicon."""
    import platform
    import os
    
    if platform.processor() == 'arm':  # Apple Silicon
        print("Configuring for Apple Silicon...")
        
        # Set environment variables for TensorFlow Metal plugin
        os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] = 'true'
        os.environ['TF_GPU_THREAD_MODE'] = 'gpu_private'
        
        # Import and configure torch for MPS
        import torch
        if hasattr(torch, 'mps') and torch.backends.mps.is_available():
            print("- Metal Performance Shaders (MPS) backend available")
            torch.backends.mps.enabled = True
        else:
            print("- MPS not available, using CPU")
    else:
        print("Not running on Apple Silicon")

# Call this function early
optimize_for_apple_silicon()
