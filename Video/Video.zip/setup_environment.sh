#!/bin/bash
# Create a new conda environment for py-feat with Apple Silicon optimizations
conda create -n pyfeat_debate python=3.9 -y
conda activate pyfeat_debate

# Pin NumPy to a compatible version first to avoid NumPy 2.0 compatibility issues
pip install "numpy<2.0.0"

# Install Apple-optimized ML libraries 
conda install -c apple tensorflow-deps -y

# Install py-feat with its dependencies
pip install py-feat

# Install visualization dependencies (pinned versions for compatibility)
pip install matplotlib seaborn plotly pandas
pip install scikit-learn  # Needed for candidate identification

# Install video processing libraries - install moviepy properly
pip uninstall -y moviepy  # Remove any problematic installation
pip uninstall -y decorator  # Remove potentially conflicting decorator package
pip install decorator==4.4.2  # Install specific version for compatibility
pip install moviepy==1.0.3  # Install specific version of moviepy

# Verify moviepy installation
echo "Checking moviepy installation:"
python -c "import moviepy.editor; print('moviepy.editor imported successfully')"

# Install video processing libraries
pip install opencv-python ffmpeg-python

# Install optional utilities for performance
pip install tqdm ipywidgets

# Install notebook environment
pip install jupyter notebook

# Verify installation and numpy version
echo "Checking numpy version and py-feat installation:"
python -c "import numpy; import feat; print(f'NumPy version: {numpy.__version__}'); print(f'py-feat version: {feat.__version__}')"

# Create and launch the notebook
mkdir -p debate_analysis
cd debate_analysis
jupyter notebook debate_emotion_analysis.ipynb
