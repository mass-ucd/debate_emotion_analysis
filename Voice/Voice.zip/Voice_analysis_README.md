#!/bin/bash
# Ciaran's Setup for Emotion & Video Analysis in Google Colab

# Environment: Google Colab (x86_64 CPU + NVIDIA A100 GPU)
# Python version: 3.11.12
# NumPy version: 2.0.2
# GPU: NVIDIA A100-SXM4-40GB

# NOTE: py-feat is not installed by default in this Colab environment.
# You must install it manually.

# Fix NumPy compatibility if needed (NumPy 2.0 may cause issues with some libraries)
pip install "numpy<2.0.0"

# Install py-feat
pip install py-feat

# Install visualization and analysis dependencies
pip install matplotlib seaborn plotly pandas
pip install scikit-learn  # Needed for machine learning and data preprocessing

# Install video processing libraries
pip uninstall -y moviepy  # Remove any preinstalled/conflicting versions
pip uninstall -y decorator
pip install decorator==4.4.2
pip install moviepy==1.0.3

# Install video and multimedia utilities
pip install opencv-python ffmpeg-python

# Install additional utilities
pip install tqdm ipywidgets

# Install Jupyter (Colab already includes it, but for completeness)
pip install jupyter notebook

# Confirm successful installations
echo "=== System Info ==="
python -c "
import sys, platform, numpy
print(f'Python version: {sys.version}')
print(f'Platform: {platform.machine()} / {platform.processor()}')
print(f'NumPy version: {numpy.__version__}')
"

# Check py-feat installation
python -c "import feat; print(f'py-feat version: {feat.__version__}')"

# Check video editing support
python -c "import moviepy.editor; print('moviepy.editor imported successfully')"

# Create working directory (optional)
mkdir -p debate_analysis
cd debate_analysis

# Launch notebook (if running locally; Colab handles this automatically)
# jupyter notebook debate_emotion_analysis.ipynb
