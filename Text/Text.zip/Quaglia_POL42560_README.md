
# POL42560 Final Project: Emotional Expression in the 2024 Trump vs. Harris Presidential Debate

This project analyzes the **emotional and linguistic expression** in the full-length **2024 U.S. Presidential Debate between Donald Trump and Kamala Harris**. 
The analysis pipeline combines **speech-to-text transcription**, **tokenization and part-of-speech tagging**, 
and **linguistic visualization** to explore political language and rhetoric.

---

## Project Objectives

- Transcribe a full political debate using Whisper.
- Tokenize, tag, and filter text using NLTK and custom stopwords.
- Visualize linguistic structures and word usage patterns.
- Export timestamped transcript and analysis-ready data for further research.

---

## Runtime & Environment

This project was developed and executed in **Google Colab**, using:

- **Hardware Accelerator**: T4 GPU
- **Python** version ≥ 3.10
- **Google Drive integration** to store and access large media files.

---

## Tools and Libraries

- `transformers` – Hugging Face's Whisper for speech transcription
- `ffmpeg` – Audio extraction from video
- `nltk` – Tokenization, POS tagging, and stopword filtering
- `pandas` – Data wrangling and CSV I/O
- `matplotlib`, `seaborn`, `WordCloud` – Visualization
- `subprocess`, `os`, `requests` – System interaction and resource handling

---

## Step-by-Step Description

### 1. Mount Google Drive
Used `google.colab.drive` to mount the Drive and access the input video.

### 2. List and verify video path
Checked the file structure to ensure proper path to:
```
Trump Vs Harris｜ Full 2024 Presidential Debate.mp4
```

### 3. Convert video to mono-channel WAV audio
Used `ffmpeg` to convert the `.mp4` video to 16kHz `.wav` format.

### 4. Run transcription with Whisper
Loaded `openai/whisper-small` using Hugging Face’s `pipeline("automatic-speech-recognition")`. Transcribed audio with timestamps, enabling segment-level analysis.

### 5. Save transcript to CSV
Parsed Whisper's chunked output into a `pandas` DataFrame with:
- `start` and `end` timestamps
- `text` segment

Saved as:  
```
debate_transcript_with_timestamps.csv
```

### 6. Download NLTK resources
Downloaded fresh copies of:
- `punkt`
- `averaged_perceptron_tagger`
- `stopwords`

Ensured reproducibility by clearing and appending specific NLTK paths.

### 7. Tokenize text and apply POS tagging
Used `TreebankWordTokenizer` and `pos_tag` to tag each token.
Created frequency distributions using `collections.Counter`.

### 8. Load and apply custom stopwords
Downloaded a stopword list from GitHub and filtered tokens accordingly.

### 9. Visualize linguistic patterns
Created:
- Word frequency bar plots using `seaborn`
- POS tag distributions
- Word clouds of high-frequency terms using `WordCloud`

### 10. Export final results
All processed data saved to Google Drive for reproducibility and further analysis.

---

## File Structure

```
sofia_pol42560_full_code.py        # Main code (Colab-exported)
Trump Vs Harris Debate.mp4         # Input video
debate.wav                         # Converted audio file
debate_transcript_with_timestamps.csv  # Timestamped transcript
```

---

## Suggested Extensions

- Apply speaker diarization to separate Trump/Harris.
- Conduct emotion or sentiment classification.
- Use topic modeling to reveal dominant political themes.
- Analyze changes in tone over time (temporal sentiment).


---


## Hypothesis Testing

To statistically compare the emotional expression of the two debate participants, we performed several **independent two-sample t-tests** using `scipy.stats.ttest_ind`.
The primary hypotheses tested included:

1. **Anger Expression**  
   - Compared `trump_anger` vs. `kamala_anger`  
   - `equal_var=False` specified due to likely unequal variances

2. **Calmness and Emotional Tone**  
   - Compared `harris_calm` vs. `trump_calm`  
   - Evaluated emotional neutrality and tonal control

3. **Charged Language**  
   - Tested whether Trump or Harris used more emotionally "charged" language  
   - Variables: `trump_charged` vs. `harris_charged`

4. **Policy Focus vs. Rhetorical Appeal**  
   - Compared prevalence of policy-oriented content (`harris_policy`, `trump_policy`)  
   - Assessed balance between rhetoric and substantive content

5. **Internal Gender Comparisons (Control)**  
   - For Harris: `harris_reb` vs. `harris_non`  
   - For Trump: `trump_reb` vs. `trump_non`  
   - Checked consistency across rhetorical registers within each speaker

Each test produced a `t-statistic` and `p-value` to evaluate whether observed differences were statistically significant. 
The tests were conducted under the assumption of **independent samples and unequal variances** to reflect the different speaking styles and segment structures.
---

## Author

**Sofia Quaglia**  
PhD Candidate, Quantitative and Computational Social Sciences  
University College Dublin – POL42560

---

## License

This code is for academic and non-commercial research purposes only.


